

#include<iostream>
#include"deck.h"
using namespace std;







void main()
{
	//calls default constructor, creat a constuctor, constucter creats a defult card,defualt is ace and spades for some resone
	/* Card myCard;
	myCard.Print();

	Card myCard1;
	Card myCard2(Ten,Hearts);

	cout << myCard.GetFaceValue;
	myCard.SetFaceValue(Nine);
	myCard.Print();

	if(myCard1 > myCard2)
		cout <<"Player 1 wins";
	else if(myCard1 == myCard2)
		cout << "Its a Tie";

	*/


     Card card1;
	 Card card2;
	 int pot = 0;
	 int p1 = 0, p2 =0;
	 int round = 0;
	 Deck laDeck;
	 laDeck.Shuffle();


	 while(laDeck.EmptyDeck() == false)
	 {
		 card1 = laDeck.DealACard();
		 card2 = laDeck.DealACard();
		 pot = pot + 2;
		 if(card1 > card2)
		    p1 += 2;
	     else if(card2 > card1)
		p2 += 2;
		else
		{
			p1 = p1 ++;
			p2 = p2 ++;
		}

	    cout << "Round " << round << endl;
		cout << "Player 1 Card = "; 
		card1.Print();
		cout << "Player Two Card = "; 
		card2.Print();
		cout << "Current Score:" << endl << "Player 1 - " << p1 << endl
			<< "Player 2 - " << p2 << endl;
		round ++;
		system("pause");
	

	 }
	
	 cout << "Game Over" << endl;
		if (p1 > p2)
			cout << "Player 1 is the winner!" << endl;
		else if(p2 > p1)
			cout << "Player 2 is the winner!" << endl;
		else
			cout << "Tie!" << endl;

}









